-- Drop database alex_gracia
drop database if exists alex_gracia;